package checkPrimesMultithreading.util;

public interface FileDisplayInterface {
	public void printLineToFile(String line, String filename);

}
