package checkPrimesMultithreading.util;


public interface StdoutDisplayInterface {
	public void printLineToStdout(String line);
	public void writeSumToScreen();
}
